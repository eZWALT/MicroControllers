/* 
 * Created:   2021
 * Processor: PIC18F45K22
 * Compiler:  MPLAB XC8
 */

#include <xc.h>
#include <string.h>
#include "config.h"
#include "GLCD.h"
#define _XTAL_FREQ 8000000  

const char * s1 = "L7 GLCD\n";
const char * s2 = "Walter J.T.V i Lluc C.C\n";
const char * dim1 = "x=\n";
const char * dim2 = "y=\n";

void writeTxt(byte page, byte y, char * s) {
   int i=0;
   while (*s!='\n' && *s!='\0') 
   {
      putchGLCD(page, y+i, *(s++));
      i++;
   };
}	

void main(void)
{
   byte x = 0,y = 0;
   ANSELA=0x00; 
   ANSELB=0x00;                  
   ANSELC=0x00;                  
   ANSELD=0x00;                  
   
   TRISD=0x00;		   
   TRISB=0x00;
   TRISA=0x0F;
    
   PORTD=0x00;
   PORTB=0x00;  
   
   GLCDinit();		   //Inicialitzem la pantalla
   clearGLCD(0,7,0,127);   //Esborrem pantalla
   setStartLine(0);        //Definim linia d'inici

   writeTxt(4,9,s1);
   writeTxt(5,1,s2);

   __delay_ms(2000);
   clearGLCD(0,7,0,127);
   SetDot(x,y);
   writeTxt(6,20,dim1);
   writeTxt(7,20,dim2);
   byte aux,auy;
 
   while (1)
   {   
      aux = x;
      auy = y;
      if(PORTAbits.RA0 == 1){
	 __delay_ms(30);
	 ClearDot(x,y);
	 ++y;
	 y %= 128;

      }
      else if(PORTAbits.RA1 == 1){
	 __delay_ms(16);
	 ClearDot(x,y);
	 --y;
	 y%= 128;
      }
      else if(PORTAbits.RA2 == 1){
	 __delay_ms(16);
	 ClearDot(x,y);
	 ++x; 
	 x %= 64;
      }
      else if(PORTAbits.RA3 == 1){
	 __delay_ms(16);
	 ClearDot(x,y);
	 --x;
	 x %= 64;
      }
      //else __delay_ms(100);
      SetDot(x,y);
      if(y != auy) clearGLCD(6,6,110,125);
      if(x != aux) clearGLCD(7,7,110,125);
      writeNum(6,22,y);
      writeNum(7,22,x);
      __delay_ms(50);
   }
}

