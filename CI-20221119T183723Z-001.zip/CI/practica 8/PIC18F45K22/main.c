/* 
 * Created:   2021
 * Processor: PIC18F45K22
 * Compiler:  MPLAB XC8
 */

#include <xc.h>
#include <string.h>
#include "config.h"
#include "GLCD.h"
#define _XTAL_FREQ 8000000  

//MAPPING MATRICIAL DEL TECLAT
const char keyboard[4][10] = {{'0','1','2','3','4','5','6','7','8','9'},{'Q','W','E','R','T','Y','U','I','O','P'},{'A','S','D','F','G','H','J','K','L','@'},{'Z','X','C','V','B','N','M',',','.',' '}};

void writeTxt(byte page, byte y, char * s) {
   int i=0;
   while (*s!='\n' && *s!='\0') 
   {
      putchGLCD(page, y+i, *(s++));
      i++;
   };
}

//FUNCIO UTIL PER INICIALITZAR EL TECLAT
void initKEYBOARD(void){
   
   char aux;
   for(int i = 0; i < 4; ++i){ //NECESSITEM 10 posicions mes pels espais
      int counter = 0;
      for(int j = 0; j < 20; ++j){ 
	 if(j%2 == 0) aux = ' ';
	 else{
	    putchGLCD(i+1,j+2,keyboard[i][counter]);
	    ++counter;
	 }
      }
   }
   //ARA NECESSITEM LA CAIXA DE EL NOM
   
   for(int r = 42;r <= 56; ++r) SetDot(r,12);
   for(int h = 42; h <= 56; ++h) SetDot(h,112); 
   
   for(int k = 12; k <= 112 ; ++k){
      SetDot(42,k);
      SetDot(56,k);
   }
   //INVERTIM EL PRIMER DE TOTS
   INVERSEputchGLCD(1,3,'0');
}

struct Name{
   byte screenX,screenY; //Aquests bytes guarden la posicio exacta de la ultima escritura
   byte nameptr;
   byte i,j; //Son els indexos fila-columna de la matriu  
   
};

//STRUCT QUE CONTE UN "PUNTER" DEL STRING QUE ESTEM ESCRIBINT, POSICIO DINS DEL TECLAT I LA PANTALLA
void initializeName(struct Name * xd){
      xd->nameptr = 3;
      xd->i = 0;		//COMENCEM A LA PRIMERA POS DEL TECLAT
      xd->j = 0;
      xd->screenX = 1;
      xd->screenY = 3;
}

void main(void)
{
   ANSELA=0x00; 
   ANSELB=0x00;                  
   ANSELC=0x00;                  
   ANSELD=0x00;                  
   
   TRISAbits.RA5 = 0;
   TRISD=0x00;		   
   TRISB=0x00;
    
   PORTD=0x00;
   PORTB=0x00;  
   
   GLCDinit();		   //Inicialitzem la pantalla
   clearGLCD(0,7,0,127);   //Esborrem pantalla
   setStartLine(0);        //Definim linia d'inici
   initKEYBOARD();
   struct Name ptr;
   initializeName(&ptr);
   
   char name[18];	 //AQUI ES GUARDARA EL NOM ESCRIT AL TECLAT
   
   int rise_edge[5] = {0,0,0,0,0};
   //LIMITAREM LA PANTALLA DE MANERA ESTATICA, OSIGUI, NO HI FAREM MODUL. SI ESTAS A LA X MAXIMA NO POTS AUGMENTARLA NI SI ESTAS EN LA MINIMA DECREMENTARLA PER EXEMPLE.
   while (1)
   {   
      //COM A MINIM HA DE SER 1 , JA QUE SI LI RESTESSIM A 1 ENS SORTIRIEM DEL TECLAT CAP A ADALT
      if(PORTAbits.RA0 == 1 && rise_edge[0] == 0 && ptr.screenX > 1){
	 putchGLCD(ptr.screenX,ptr.screenY,keyboard[ptr.i][ptr.j]);
	 ptr.screenX--;
	 ptr.i--;
	 INVERSEputchGLCD(ptr.screenX,ptr.screenY,keyboard[ptr.i][ptr.j]);
	 rise_edge[0] = 1;
      }
      else if(PORTAbits.RA0 == 0 && rise_edge[0] == 1) rise_edge[0] = 0;
      
      //HEM DE LIMITARHO A 4, PERQUE SI ES IGUAL A 4 ESTA EN LA X MES BAIXA I NO POT BAIXAR MES
      if(PORTAbits.RA1 == 1 && rise_edge[1] == 0 && ptr.screenX < 4){
	 putchGLCD(ptr.screenX,ptr.screenY,keyboard[ptr.i][ptr.j]);
	 ptr.screenX++;
	 ptr.i++;
	 INVERSEputchGLCD(ptr.screenX,ptr.screenY,keyboard[ptr.i][ptr.j]);
	 rise_edge[1] = 1;
      }
      else if(PORTAbits.RA1 == 0 && rise_edge[1] == 1) rise_edge[1] = 0;
      
      //HEM D'ESTABLIR LIMIT 4 PER QUE SI LI RESTEM 2 ES QUEDI A LA PRIMERA POSICIO
      if(PORTAbits.RA2 == 1 && rise_edge[2] == 0 && ptr.screenY >= 4){
	 putchGLCD(ptr.screenX,ptr.screenY,keyboard[ptr.i][ptr.j]);
	 ptr.screenY -= 2;
	 ptr.j--;
	 INVERSEputchGLCD(ptr.screenX,ptr.screenY,keyboard[ptr.i][ptr.j]);
	 rise_edge[2] = 1;
      }
      else if(PORTAbits.RA2 == 0 && rise_edge[2] == 1) rise_edge[2] = 0;
      
      //COM A MAXIM POT SER MES PETIT QUE 20, JA QUE SI LI SUMESSIM 2 SERIA 20, LA POSICIO MES GRAN.
      if(PORTAbits.RA3 == 1 && rise_edge[3] == 0 && ptr.screenY < 20){
	 putchGLCD(ptr.screenX,ptr.screenY,keyboard[ptr.i][ptr.j]);
	 ptr.screenY += 2;
	 ptr.j++;
	 INVERSEputchGLCD(ptr.screenX,ptr.screenY,keyboard[ptr.i][ptr.j]);
	 rise_edge[3] = 1;
      }
      else if(PORTAbits.RA3 == 0 && rise_edge[3] == 1) rise_edge[3] = 0;
      
      // SHA DE LIMITAR A 18 CARACTERS
      if(PORTAbits.RA4 == 0 && rise_edge[4] == 1 && ptr.nameptr < 21){
	 putchGLCD(6,ptr.nameptr,keyboard[ptr.i][ptr.j]);
	 name[ptr.nameptr] = keyboard[ptr.i][ptr.j];
	 ptr.nameptr++;
	 rise_edge[4] = 0;
      }
      else if(PORTAbits.RA4 == 1) rise_edge[4] = 1;
      
      
      //LA FUNCIO INVERSE POSA EN NEGRETA LA LLETRA SELECCIONADA
	
   }
}
